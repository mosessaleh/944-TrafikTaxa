"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/admin/bookings/update/route";
exports.ids = ["app/api/admin/bookings/update/route"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "../../client/components/action-async-storage.external":
/*!*******************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external.js" ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/action-async-storage.external.js");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!********************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external.js" ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/request-async-storage.external.js");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!******************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external.js" ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/static-generation-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ "child_process":
/*!********************************!*\
  !*** external "child_process" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ "dns":
/*!**********************!*\
  !*** external "dns" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("dns");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute&page=%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute.ts&appDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute&page=%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute.ts&appDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_moses_Projects_Websites_944_TrafikTaxa_app_api_admin_bookings_update_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/admin/bookings/update/route.ts */ \"(rsc)/./app/api/admin/bookings/update/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/admin/bookings/update/route\",\n        pathname: \"/api/admin/bookings/update\",\n        filename: \"route\",\n        bundlePath: \"app/api/admin/bookings/update/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\moses\\\\Projects\\\\Websites\\\\944-TrafikTaxa\\\\app\\\\api\\\\admin\\\\bookings\\\\update\\\\route.ts\",\n    nextConfigOutput,\n    userland: C_Users_moses_Projects_Websites_944_TrafikTaxa_app_api_admin_bookings_update_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/admin/bookings/update/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZhZG1pbiUyRmJvb2tpbmdzJTJGdXBkYXRlJTJGcm91dGUmcGFnZT0lMkZhcGklMkZhZG1pbiUyRmJvb2tpbmdzJTJGdXBkYXRlJTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGYWRtaW4lMkZib29raW5ncyUyRnVwZGF0ZSUyRnJvdXRlLnRzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNtb3NlcyU1Q1Byb2plY3RzJTVDV2Vic2l0ZXMlNUM5NDQtVHJhZmlrVGF4YSU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9QyUzQSU1Q1VzZXJzJTVDbW9zZXMlNUNQcm9qZWN0cyU1Q1dlYnNpdGVzJTVDOTQ0LVRyYWZpa1RheGEmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFzRztBQUN2QztBQUNjO0FBQ2lEO0FBQzlIO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnSEFBbUI7QUFDM0M7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsaUVBQWlFO0FBQ3pFO0FBQ0E7QUFDQSxXQUFXLDRFQUFXO0FBQ3RCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDdUg7O0FBRXZIIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vOTQ0LXRyYWZpay8/MmEzNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBSb3V0ZVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvYXBwLXJvdXRlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJDOlxcXFxVc2Vyc1xcXFxtb3Nlc1xcXFxQcm9qZWN0c1xcXFxXZWJzaXRlc1xcXFw5NDQtVHJhZmlrVGF4YVxcXFxhcHBcXFxcYXBpXFxcXGFkbWluXFxcXGJvb2tpbmdzXFxcXHVwZGF0ZVxcXFxyb3V0ZS50c1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvYWRtaW4vYm9va2luZ3MvdXBkYXRlL3JvdXRlXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvYWRtaW4vYm9va2luZ3MvdXBkYXRlXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS9hZG1pbi9ib29raW5ncy91cGRhdGUvcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCJDOlxcXFxVc2Vyc1xcXFxtb3Nlc1xcXFxQcm9qZWN0c1xcXFxXZWJzaXRlc1xcXFw5NDQtVHJhZmlrVGF4YVxcXFxhcHBcXFxcYXBpXFxcXGFkbWluXFxcXGJvb2tpbmdzXFxcXHVwZGF0ZVxcXFxyb3V0ZS50c1wiLFxuICAgIG5leHRDb25maWdPdXRwdXQsXG4gICAgdXNlcmxhbmRcbn0pO1xuLy8gUHVsbCBvdXQgdGhlIGV4cG9ydHMgdGhhdCB3ZSBuZWVkIHRvIGV4cG9zZSBmcm9tIHRoZSBtb2R1bGUuIFRoaXMgc2hvdWxkXG4vLyBiZSBlbGltaW5hdGVkIHdoZW4gd2UndmUgbW92ZWQgdGhlIG90aGVyIHJvdXRlcyB0byB0aGUgbmV3IGZvcm1hdC4gVGhlc2Vcbi8vIGFyZSB1c2VkIHRvIGhvb2sgaW50byB0aGUgcm91dGUuXG5jb25zdCB7IHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmNvbnN0IG9yaWdpbmFsUGF0aG5hbWUgPSBcIi9hcGkvYWRtaW4vYm9va2luZ3MvdXBkYXRlL3JvdXRlXCI7XG5mdW5jdGlvbiBwYXRjaEZldGNoKCkge1xuICAgIHJldHVybiBfcGF0Y2hGZXRjaCh7XG4gICAgICAgIHNlcnZlckhvb2tzLFxuICAgICAgICBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlXG4gICAgfSk7XG59XG5leHBvcnQgeyByb3V0ZU1vZHVsZSwgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIG9yaWdpbmFsUGF0aG5hbWUsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute&page=%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute.ts&appDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/admin/bookings/update/route.ts":
/*!************************************************!*\
  !*** ./app/api/admin/bookings/update/route.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! zod */ \"(rsc)/./node_modules/zod/v3/types.js\");\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/db */ \"(rsc)/./lib/db.ts\");\n/* harmony import */ var _lib_email__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/lib/email */ \"(rsc)/./lib/email.ts\");\n/* harmony import */ var _lib_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/lib/auth */ \"(rsc)/./lib/auth.ts\");\n\n\n\n\n\nconst Schema = zod__WEBPACK_IMPORTED_MODULE_4__.object({\n    id: zod__WEBPACK_IMPORTED_MODULE_4__.number().int(),\n    action: zod__WEBPACK_IMPORTED_MODULE_4__[\"enum\"]([\n        \"CONFIRM\",\n        \"DISPATCH\",\n        \"START\",\n        \"COMPLETE\",\n        \"CANCEL\",\n        \"MARK_PAID\"\n    ])\n});\nfunction emailTpl(subject, body) {\n    return {\n        subject,\n        html: `<div style=\"font-family:Arial,Helvetica,sans-serif;line-height:1.6;color:#0f172a\">\\n  <h2 style=\"margin:0 0 12px\">${subject}</h2>\\n  <p>${body}</p>\\n  <p style=\"margin-top:16px;color:#475569;font-size:13px\">— 944 Trafik<br/>Frederikssund — Phone: 26444944 — Email: trafik@944.dk</p>\\n</div>`\n    };\n}\nasync function POST(req) {\n    try {\n        await (0,_lib_auth__WEBPACK_IMPORTED_MODULE_3__.requireAdmin)();\n    } catch (e) {\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            ok: false,\n            error: \"Forbidden\"\n        }, {\n            status: e?.status || 403\n        });\n    }\n    try {\n        const { id, action } = Schema.parse(await req.json());\n        const ride = await _lib_db__WEBPACK_IMPORTED_MODULE_1__.prisma.ride.findUnique({\n            where: {\n                id\n            },\n            include: {\n                user: true\n            }\n        });\n        if (!ride) return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            ok: false,\n            error: \"Ride not found\"\n        }, {\n            status: 404\n        });\n        let data = {};\n        if (action === \"CONFIRM\") data.status = \"CONFIRMED\";\n        if (action === \"DISPATCH\") data.status = \"DISPATCHED\";\n        if (action === \"START\") data.status = \"ONGOING\";\n        if (action === \"COMPLETE\") data.status = \"COMPLETED\";\n        if (action === \"CANCEL\") data.status = \"CANCELED\";\n        if (action === \"MARK_PAID\") data.paid = true;\n        const updated = await _lib_db__WEBPACK_IMPORTED_MODULE_1__.prisma.ride.update({\n            where: {\n                id\n            },\n            data\n        });\n        const email = ride.user.email;\n        const when = new Date(ride.pickupTime).toLocaleString();\n        try {\n            if (action === \"CONFIRM\") {\n                const { subject, html } = emailTpl(\"Your booking is confirmed\", `We have confirmed your ride <b>#${ride.id}</b> scheduled for <b>${when}</b>.<br/>You will be notified once a car is dispatched.`);\n                await (0,_lib_email__WEBPACK_IMPORTED_MODULE_2__.sendEmail)(email, subject, html);\n            }\n            if (action === \"DISPATCH\") {\n                const { subject, html } = emailTpl(\"Your car is on the way\", `A car has been dispatched for your ride <b>#${ride.id}</b>. The driver will arrive as soon as possible.`);\n                await (0,_lib_email__WEBPACK_IMPORTED_MODULE_2__.sendEmail)(email, subject, html);\n            }\n            if (action === \"COMPLETE\") {\n                const { subject, html } = emailTpl(\"Your ride is completed\", `Your ride <b>#${ride.id}</b> has been completed. Thank you for choosing 944 Trafik.`);\n                await (0,_lib_email__WEBPACK_IMPORTED_MODULE_2__.sendEmail)(email, subject, html);\n            }\n            if (action === \"CANCEL\") {\n                const { subject, html } = emailTpl(\"Your booking was canceled\", `Your ride <b>#${ride.id}</b> has been canceled. If this was a mistake, you can book a new ride anytime.`);\n                await (0,_lib_email__WEBPACK_IMPORTED_MODULE_2__.sendEmail)(email, subject, html);\n            }\n        } catch (e) {\n            console.warn(\"[mail] admin update email failed\", e);\n        }\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            ok: true,\n            ride: updated\n        });\n    } catch (e) {\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            ok: false,\n            error: e?.message || \"Invalid\"\n        }, {\n            status: 400\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2FkbWluL2Jvb2tpbmdzL3VwZGF0ZS9yb3V0ZS50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBMkM7QUFDbkI7QUFDVTtBQUNNO0FBQ0U7QUFFMUMsTUFBTUssU0FBU0osdUNBQVEsQ0FBQztJQUFFTSxJQUFJTix1Q0FBUSxHQUFHUSxHQUFHO0lBQUlDLFFBQVFULHdDQUFNLENBQUM7UUFBQztRQUFVO1FBQVc7UUFBUTtRQUFXO1FBQVM7S0FBWTtBQUFFO0FBRS9ILFNBQVNXLFNBQVNDLE9BQWMsRUFBRUMsSUFBVztJQUMzQyxPQUFPO1FBQUVEO1FBQVNFLE1BQU0sQ0FBQyxrSEFBa0gsRUFBRUYsUUFBUSxZQUFZLEVBQUVDLEtBQUssbUpBQW1KLENBQUM7SUFBQztBQUMvVDtBQUVPLGVBQWVFLEtBQUtDLEdBQVk7SUFDckMsSUFBRztRQUFFLE1BQU1iLHVEQUFZQTtJQUFJLEVBQUMsT0FBTWMsR0FBTTtRQUFFLE9BQU9sQixxREFBWUEsQ0FBQ21CLElBQUksQ0FBQztZQUFFQyxJQUFHO1lBQU9DLE9BQU07UUFBWSxHQUFHO1lBQUVDLFFBQVFKLEdBQUdJLFVBQVE7UUFBSTtJQUFJO0lBQ2pJLElBQUc7UUFDRCxNQUFNLEVBQUVmLEVBQUUsRUFBRUcsTUFBTSxFQUFFLEdBQUdMLE9BQU9rQixLQUFLLENBQUMsTUFBTU4sSUFBSUUsSUFBSTtRQUNsRCxNQUFNSyxPQUFPLE1BQU10QiwyQ0FBTUEsQ0FBQ3NCLElBQUksQ0FBQ0MsVUFBVSxDQUFDO1lBQUVDLE9BQU07Z0JBQUVuQjtZQUFHO1lBQUdvQixTQUFRO2dCQUFFQyxNQUFLO1lBQUs7UUFBRTtRQUNoRixJQUFJLENBQUNKLE1BQU0sT0FBT3hCLHFEQUFZQSxDQUFDbUIsSUFBSSxDQUFDO1lBQUVDLElBQUc7WUFBT0MsT0FBTTtRQUFpQixHQUFFO1lBQUVDLFFBQU87UUFBSTtRQUV0RixJQUFJTyxPQUFXLENBQUM7UUFDaEIsSUFBSW5CLFdBQVMsV0FBV21CLEtBQUtQLE1BQU0sR0FBQztRQUNwQyxJQUFJWixXQUFTLFlBQVltQixLQUFLUCxNQUFNLEdBQUM7UUFDckMsSUFBSVosV0FBUyxTQUFTbUIsS0FBS1AsTUFBTSxHQUFDO1FBQ2xDLElBQUlaLFdBQVMsWUFBWW1CLEtBQUtQLE1BQU0sR0FBQztRQUNyQyxJQUFJWixXQUFTLFVBQVVtQixLQUFLUCxNQUFNLEdBQUM7UUFDbkMsSUFBSVosV0FBUyxhQUFhbUIsS0FBS0MsSUFBSSxHQUFDO1FBRXBDLE1BQU1DLFVBQVUsTUFBTTdCLDJDQUFNQSxDQUFDc0IsSUFBSSxDQUFDUSxNQUFNLENBQUM7WUFBRU4sT0FBTTtnQkFBRW5CO1lBQUc7WUFBR3NCO1FBQUs7UUFFOUQsTUFBTUksUUFBUVQsS0FBS0ksSUFBSSxDQUFDSyxLQUFLO1FBQzdCLE1BQU1DLE9BQU8sSUFBSUMsS0FBS1gsS0FBS1ksVUFBVSxFQUFFQyxjQUFjO1FBQ3JELElBQUc7WUFDRCxJQUFJM0IsV0FBUyxXQUFVO2dCQUNyQixNQUFNLEVBQUVHLE9BQU8sRUFBRUUsSUFBSSxFQUFFLEdBQUdILFNBQVMsNkJBQTZCLENBQUMsZ0NBQWdDLEVBQUVZLEtBQUtqQixFQUFFLENBQUMsc0JBQXNCLEVBQUUyQixLQUFLLHdEQUF3RCxDQUFDO2dCQUNqTSxNQUFNL0IscURBQVNBLENBQUM4QixPQUFPcEIsU0FBU0U7WUFDbEM7WUFDQSxJQUFJTCxXQUFTLFlBQVc7Z0JBQ3RCLE1BQU0sRUFBRUcsT0FBTyxFQUFFRSxJQUFJLEVBQUUsR0FBR0gsU0FBUywwQkFBMEIsQ0FBQyw0Q0FBNEMsRUFBRVksS0FBS2pCLEVBQUUsQ0FBQyxpREFBaUQsQ0FBQztnQkFDdEssTUFBTUoscURBQVNBLENBQUM4QixPQUFPcEIsU0FBU0U7WUFDbEM7WUFDQSxJQUFJTCxXQUFTLFlBQVc7Z0JBQ3RCLE1BQU0sRUFBRUcsT0FBTyxFQUFFRSxJQUFJLEVBQUUsR0FBR0gsU0FBUywwQkFBMEIsQ0FBQyxjQUFjLEVBQUVZLEtBQUtqQixFQUFFLENBQUMsMkRBQTJELENBQUM7Z0JBQ2xKLE1BQU1KLHFEQUFTQSxDQUFDOEIsT0FBT3BCLFNBQVNFO1lBQ2xDO1lBQ0EsSUFBSUwsV0FBUyxVQUFTO2dCQUNwQixNQUFNLEVBQUVHLE9BQU8sRUFBRUUsSUFBSSxFQUFFLEdBQUdILFNBQVMsNkJBQTZCLENBQUMsY0FBYyxFQUFFWSxLQUFLakIsRUFBRSxDQUFDLCtFQUErRSxDQUFDO2dCQUN6SyxNQUFNSixxREFBU0EsQ0FBQzhCLE9BQU9wQixTQUFTRTtZQUNsQztRQUNGLEVBQUMsT0FBTUcsR0FBRTtZQUFFb0IsUUFBUUMsSUFBSSxDQUFDLG9DQUFvQ3JCO1FBQUk7UUFFaEUsT0FBT2xCLHFEQUFZQSxDQUFDbUIsSUFBSSxDQUFDO1lBQUVDLElBQUc7WUFBTUksTUFBTU87UUFBUTtJQUNwRCxFQUFDLE9BQU1iLEdBQU07UUFDWCxPQUFPbEIscURBQVlBLENBQUNtQixJQUFJLENBQUM7WUFBRUMsSUFBRztZQUFPQyxPQUFPSCxHQUFHc0IsV0FBUztRQUFVLEdBQUU7WUFBRWxCLFFBQU87UUFBSTtJQUNuRjtBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vOTQ0LXRyYWZpay8uL2FwcC9hcGkvYWRtaW4vYm9va2luZ3MvdXBkYXRlL3JvdXRlLnRzP2EwYTIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmV4dFJlc3BvbnNlIH0gZnJvbSAnbmV4dC9zZXJ2ZXInO1xuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCc7XG5pbXBvcnQgeyBwcmlzbWEgfSBmcm9tICdAL2xpYi9kYic7XG5pbXBvcnQgeyBzZW5kRW1haWwgfSBmcm9tICdAL2xpYi9lbWFpbCc7XG5pbXBvcnQgeyByZXF1aXJlQWRtaW4gfSBmcm9tICdAL2xpYi9hdXRoJztcblxuY29uc3QgU2NoZW1hID0gei5vYmplY3QoeyBpZDogei5udW1iZXIoKS5pbnQoKSwgYWN0aW9uOiB6LmVudW0oWydDT05GSVJNJywnRElTUEFUQ0gnLCdTVEFSVCcsJ0NPTVBMRVRFJywnQ0FOQ0VMJywnTUFSS19QQUlEJ10pIH0pO1xuXG5mdW5jdGlvbiBlbWFpbFRwbChzdWJqZWN0OnN0cmluZywgYm9keTpzdHJpbmcpe1xuICByZXR1cm4geyBzdWJqZWN0LCBodG1sOiBgPGRpdiBzdHlsZT1cImZvbnQtZmFtaWx5OkFyaWFsLEhlbHZldGljYSxzYW5zLXNlcmlmO2xpbmUtaGVpZ2h0OjEuNjtjb2xvcjojMGYxNzJhXCI+XFxuICA8aDIgc3R5bGU9XCJtYXJnaW46MCAwIDEycHhcIj4ke3N1YmplY3R9PC9oMj5cXG4gIDxwPiR7Ym9keX08L3A+XFxuICA8cCBzdHlsZT1cIm1hcmdpbi10b3A6MTZweDtjb2xvcjojNDc1NTY5O2ZvbnQtc2l6ZToxM3B4XCI+4oCUIDk0NCBUcmFmaWs8YnIvPkZyZWRlcmlrc3N1bmQg4oCUIFBob25lOiAyNjQ0NDk0NCDigJQgRW1haWw6IHRyYWZpa0A5NDQuZGs8L3A+XFxuPC9kaXY+YCB9O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gUE9TVChyZXE6IFJlcXVlc3Qpe1xuICB0cnl7IGF3YWl0IHJlcXVpcmVBZG1pbigpOyB9Y2F0Y2goZTphbnkpeyByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBvazpmYWxzZSwgZXJyb3I6J0ZvcmJpZGRlbicgfSwgeyBzdGF0dXM6IGU/LnN0YXR1c3x8NDAzIH0pOyB9XG4gIHRyeXtcbiAgICBjb25zdCB7IGlkLCBhY3Rpb24gfSA9IFNjaGVtYS5wYXJzZShhd2FpdCByZXEuanNvbigpKTtcbiAgICBjb25zdCByaWRlID0gYXdhaXQgcHJpc21hLnJpZGUuZmluZFVuaXF1ZSh7IHdoZXJlOnsgaWQgfSwgaW5jbHVkZTp7IHVzZXI6dHJ1ZSB9IH0pO1xuICAgIGlmICghcmlkZSkgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgb2s6ZmFsc2UsIGVycm9yOidSaWRlIG5vdCBmb3VuZCcgfSx7IHN0YXR1czo0MDQgfSk7XG5cbiAgICBsZXQgZGF0YTphbnkgPSB7fTtcbiAgICBpZiAoYWN0aW9uPT09J0NPTkZJUk0nKSBkYXRhLnN0YXR1cz0nQ09ORklSTUVEJztcbiAgICBpZiAoYWN0aW9uPT09J0RJU1BBVENIJykgZGF0YS5zdGF0dXM9J0RJU1BBVENIRUQnO1xuICAgIGlmIChhY3Rpb249PT0nU1RBUlQnKSBkYXRhLnN0YXR1cz0nT05HT0lORyc7XG4gICAgaWYgKGFjdGlvbj09PSdDT01QTEVURScpIGRhdGEuc3RhdHVzPSdDT01QTEVURUQnO1xuICAgIGlmIChhY3Rpb249PT0nQ0FOQ0VMJykgZGF0YS5zdGF0dXM9J0NBTkNFTEVEJztcbiAgICBpZiAoYWN0aW9uPT09J01BUktfUEFJRCcpIGRhdGEucGFpZD10cnVlO1xuXG4gICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IHByaXNtYS5yaWRlLnVwZGF0ZSh7IHdoZXJlOnsgaWQgfSwgZGF0YSB9KTtcblxuICAgIGNvbnN0IGVtYWlsID0gcmlkZS51c2VyLmVtYWlsO1xuICAgIGNvbnN0IHdoZW4gPSBuZXcgRGF0ZShyaWRlLnBpY2t1cFRpbWUpLnRvTG9jYWxlU3RyaW5nKCk7XG4gICAgdHJ5e1xuICAgICAgaWYgKGFjdGlvbj09PSdDT05GSVJNJyl7XG4gICAgICAgIGNvbnN0IHsgc3ViamVjdCwgaHRtbCB9ID0gZW1haWxUcGwoJ1lvdXIgYm9va2luZyBpcyBjb25maXJtZWQnLCBgV2UgaGF2ZSBjb25maXJtZWQgeW91ciByaWRlIDxiPiMke3JpZGUuaWR9PC9iPiBzY2hlZHVsZWQgZm9yIDxiPiR7d2hlbn08L2I+Ljxici8+WW91IHdpbGwgYmUgbm90aWZpZWQgb25jZSBhIGNhciBpcyBkaXNwYXRjaGVkLmApO1xuICAgICAgICBhd2FpdCBzZW5kRW1haWwoZW1haWwsIHN1YmplY3QsIGh0bWwpO1xuICAgICAgfVxuICAgICAgaWYgKGFjdGlvbj09PSdESVNQQVRDSCcpe1xuICAgICAgICBjb25zdCB7IHN1YmplY3QsIGh0bWwgfSA9IGVtYWlsVHBsKCdZb3VyIGNhciBpcyBvbiB0aGUgd2F5JywgYEEgY2FyIGhhcyBiZWVuIGRpc3BhdGNoZWQgZm9yIHlvdXIgcmlkZSA8Yj4jJHtyaWRlLmlkfTwvYj4uIFRoZSBkcml2ZXIgd2lsbCBhcnJpdmUgYXMgc29vbiBhcyBwb3NzaWJsZS5gKTtcbiAgICAgICAgYXdhaXQgc2VuZEVtYWlsKGVtYWlsLCBzdWJqZWN0LCBodG1sKTtcbiAgICAgIH1cbiAgICAgIGlmIChhY3Rpb249PT0nQ09NUExFVEUnKXtcbiAgICAgICAgY29uc3QgeyBzdWJqZWN0LCBodG1sIH0gPSBlbWFpbFRwbCgnWW91ciByaWRlIGlzIGNvbXBsZXRlZCcsIGBZb3VyIHJpZGUgPGI+IyR7cmlkZS5pZH08L2I+IGhhcyBiZWVuIGNvbXBsZXRlZC4gVGhhbmsgeW91IGZvciBjaG9vc2luZyA5NDQgVHJhZmlrLmApO1xuICAgICAgICBhd2FpdCBzZW5kRW1haWwoZW1haWwsIHN1YmplY3QsIGh0bWwpO1xuICAgICAgfVxuICAgICAgaWYgKGFjdGlvbj09PSdDQU5DRUwnKXtcbiAgICAgICAgY29uc3QgeyBzdWJqZWN0LCBodG1sIH0gPSBlbWFpbFRwbCgnWW91ciBib29raW5nIHdhcyBjYW5jZWxlZCcsIGBZb3VyIHJpZGUgPGI+IyR7cmlkZS5pZH08L2I+IGhhcyBiZWVuIGNhbmNlbGVkLiBJZiB0aGlzIHdhcyBhIG1pc3Rha2UsIHlvdSBjYW4gYm9vayBhIG5ldyByaWRlIGFueXRpbWUuYCk7XG4gICAgICAgIGF3YWl0IHNlbmRFbWFpbChlbWFpbCwgc3ViamVjdCwgaHRtbCk7XG4gICAgICB9XG4gICAgfWNhdGNoKGUpeyBjb25zb2xlLndhcm4oJ1ttYWlsXSBhZG1pbiB1cGRhdGUgZW1haWwgZmFpbGVkJywgZSk7IH1cblxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IG9rOnRydWUsIHJpZGU6IHVwZGF0ZWQgfSk7XG4gIH1jYXRjaChlOmFueSl7XG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgb2s6ZmFsc2UsIGVycm9yOiBlPy5tZXNzYWdlfHwnSW52YWxpZCcgfSx7IHN0YXR1czo0MDAgfSk7XG4gIH1cbn1cbiJdLCJuYW1lcyI6WyJOZXh0UmVzcG9uc2UiLCJ6IiwicHJpc21hIiwic2VuZEVtYWlsIiwicmVxdWlyZUFkbWluIiwiU2NoZW1hIiwib2JqZWN0IiwiaWQiLCJudW1iZXIiLCJpbnQiLCJhY3Rpb24iLCJlbnVtIiwiZW1haWxUcGwiLCJzdWJqZWN0IiwiYm9keSIsImh0bWwiLCJQT1NUIiwicmVxIiwiZSIsImpzb24iLCJvayIsImVycm9yIiwic3RhdHVzIiwicGFyc2UiLCJyaWRlIiwiZmluZFVuaXF1ZSIsIndoZXJlIiwiaW5jbHVkZSIsInVzZXIiLCJkYXRhIiwicGFpZCIsInVwZGF0ZWQiLCJ1cGRhdGUiLCJlbWFpbCIsIndoZW4iLCJEYXRlIiwicGlja3VwVGltZSIsInRvTG9jYWxlU3RyaW5nIiwiY29uc29sZSIsIndhcm4iLCJtZXNzYWdlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/admin/bookings/update/route.ts\n");

/***/ }),

/***/ "(rsc)/./lib/auth.ts":
/*!*********************!*\
  !*** ./lib/auth.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   clearSessionCookie: () => (/* binding */ clearSessionCookie),\n/* harmony export */   comparePassword: () => (/* binding */ comparePassword),\n/* harmony export */   getUserFromCookie: () => (/* binding */ getUserFromCookie),\n/* harmony export */   hashPassword: () => (/* binding */ hashPassword),\n/* harmony export */   requireAdmin: () => (/* binding */ requireAdmin),\n/* harmony export */   setSessionCookie: () => (/* binding */ setSessionCookie),\n/* harmony export */   signToken: () => (/* binding */ signToken)\n/* harmony export */ });\n/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/headers */ \"(rsc)/./node_modules/next/dist/api/headers.js\");\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/db */ \"(rsc)/./lib/db.ts\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jsonwebtoken */ \"(rsc)/./node_modules/jsonwebtoken/index.js\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _lib_crypto__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/lib/crypto */ \"(rsc)/./lib/crypto.ts\");\n\n\n\n\nconst SECRET = process.env.SECRET || \"change_me_dev_secret\";\nfunction signToken(payload) {\n    return (0,jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__.sign)(payload, SECRET, {\n        expiresIn: \"7d\"\n    });\n}\nasync function hashPassword(password) {\n    return (0,_lib_crypto__WEBPACK_IMPORTED_MODULE_3__.hashPassword)(password);\n}\nasync function comparePassword(plain, hashed) {\n    return (0,_lib_crypto__WEBPACK_IMPORTED_MODULE_3__.comparePassword)(plain, hashed);\n}\nfunction setSessionCookie(token) {\n    const jar = (0,next_headers__WEBPACK_IMPORTED_MODULE_0__.cookies)();\n    const secure = String(process.env.COOKIE_SECURE || \"false\").toLowerCase() === \"true\";\n    jar.set(\"session\", token, {\n        httpOnly: true,\n        sameSite: \"lax\",\n        secure,\n        path: \"/\",\n        maxAge: 60 * 60 * 24 * 7\n    });\n}\nfunction clearSessionCookie() {\n    const jar = (0,next_headers__WEBPACK_IMPORTED_MODULE_0__.cookies)();\n    const secure = String(process.env.COOKIE_SECURE || \"false\").toLowerCase() === \"true\";\n    jar.set(\"session\", \"\", {\n        httpOnly: true,\n        sameSite: \"lax\",\n        secure,\n        path: \"/\",\n        maxAge: 0\n    });\n}\nasync function getUserFromCookie() {\n    const token = (0,next_headers__WEBPACK_IMPORTED_MODULE_0__.cookies)().get(\"session\")?.value;\n    if (!token) return null;\n    try {\n        const dec = (0,jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__.verify)(token, SECRET);\n        const user = await _lib_db__WEBPACK_IMPORTED_MODULE_1__.prisma.user.findUnique({\n            where: {\n                id: dec.id\n            }\n        });\n        return user;\n    } catch  {\n        return null;\n    }\n}\nasync function requireAdmin() {\n    const u = await getUserFromCookie();\n    if (!u || u.role !== \"ADMIN\") throw Object.assign(new Error(\"Forbidden\"), {\n        status: 403\n    });\n    return u;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvYXV0aC50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBdUM7QUFDTDtBQUNVO0FBQytCO0FBRTNFLE1BQU1RLFNBQVNDLFFBQVFDLEdBQUcsQ0FBQ0YsTUFBTSxJQUFJO0FBRTlCLFNBQVNHLFVBQVVDLE9BQTRCO0lBQ3BELE9BQU9WLGtEQUFJQSxDQUFDVSxTQUFTSixRQUFRO1FBQUVLLFdBQVc7SUFBSztBQUNqRDtBQUVPLGVBQWVQLGFBQWFRLFFBQWdCO0lBQUcsT0FBT1AseURBQUdBLENBQUNPO0FBQVc7QUFDckUsZUFBZVYsZ0JBQWdCVyxLQUFhLEVBQUVDLE1BQWM7SUFBRyxPQUFPWCw0REFBR0EsQ0FBQ1UsT0FBT0M7QUFBUztBQUUxRixTQUFTQyxpQkFBaUJDLEtBQWE7SUFDNUMsTUFBTUMsTUFBTW5CLHFEQUFPQTtJQUNuQixNQUFNb0IsU0FBU0MsT0FBT1osUUFBUUMsR0FBRyxDQUFDWSxhQUFhLElBQUUsU0FBU0MsV0FBVyxPQUFPO0lBQzVFSixJQUFJSyxHQUFHLENBQUMsV0FBV04sT0FBTztRQUFFTyxVQUFVO1FBQU1DLFVBQVU7UUFBT047UUFBUU8sTUFBTTtRQUFLQyxRQUFRLEtBQUcsS0FBRyxLQUFHO0lBQUU7QUFDckc7QUFFTyxTQUFTQztJQUNkLE1BQU1WLE1BQU1uQixxREFBT0E7SUFDbkIsTUFBTW9CLFNBQVNDLE9BQU9aLFFBQVFDLEdBQUcsQ0FBQ1ksYUFBYSxJQUFFLFNBQVNDLFdBQVcsT0FBTztJQUM1RUosSUFBSUssR0FBRyxDQUFDLFdBQVcsSUFBSTtRQUFFQyxVQUFTO1FBQU1DLFVBQVM7UUFBT047UUFBUU8sTUFBSztRQUFLQyxRQUFRO0lBQUU7QUFDdEY7QUFFTyxlQUFlRTtJQUNwQixNQUFNWixRQUFRbEIscURBQU9BLEdBQUcrQixHQUFHLENBQUMsWUFBWUM7SUFDeEMsSUFBSSxDQUFDZCxPQUFPLE9BQU87SUFDbkIsSUFBRztRQUNELE1BQU1lLE1BQVc5QixvREFBTUEsQ0FBQ2UsT0FBT1Y7UUFDL0IsTUFBTTBCLE9BQU8sTUFBTWpDLDJDQUFNQSxDQUFDaUMsSUFBSSxDQUFDQyxVQUFVLENBQUM7WUFBRUMsT0FBTztnQkFBRUMsSUFBSUosSUFBSUksRUFBRTtZQUFDO1FBQUU7UUFDbEUsT0FBT0g7SUFDVCxFQUFDLE9BQUs7UUFBRSxPQUFPO0lBQU07QUFDdkI7QUFFTyxlQUFlSTtJQUNwQixNQUFNQyxJQUFJLE1BQU1UO0lBQ2hCLElBQUksQ0FBQ1MsS0FBS0EsRUFBRUMsSUFBSSxLQUFLLFNBQVMsTUFBTUMsT0FBT0MsTUFBTSxDQUFDLElBQUlDLE1BQU0sY0FBYztRQUFFQyxRQUFRO0lBQUk7SUFDeEYsT0FBT0w7QUFDVCIsInNvdXJjZXMiOlsid2VicGFjazovLzk0NC10cmFmaWsvLi9saWIvYXV0aC50cz9iZjdlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNvb2tpZXMgfSBmcm9tICduZXh0L2hlYWRlcnMnO1xuaW1wb3J0IHsgcHJpc21hIH0gZnJvbSAnQC9saWIvZGInO1xuaW1wb3J0IHsgc2lnbiwgdmVyaWZ5IH0gZnJvbSAnanNvbndlYnRva2VuJztcbmltcG9ydCB7IGNvbXBhcmVQYXNzd29yZCBhcyBjbXAsIGhhc2hQYXNzd29yZCBhcyBoc2ggfSBmcm9tICdAL2xpYi9jcnlwdG8nO1xuXG5jb25zdCBTRUNSRVQgPSBwcm9jZXNzLmVudi5TRUNSRVQgfHwgJ2NoYW5nZV9tZV9kZXZfc2VjcmV0JztcblxuZXhwb3J0IGZ1bmN0aW9uIHNpZ25Ub2tlbihwYXlsb2FkOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KXtcbiAgcmV0dXJuIHNpZ24ocGF5bG9hZCwgU0VDUkVULCB7IGV4cGlyZXNJbjogJzdkJyB9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhc2hQYXNzd29yZChwYXNzd29yZDogc3RyaW5nKXsgcmV0dXJuIGhzaChwYXNzd29yZCk7IH1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjb21wYXJlUGFzc3dvcmQocGxhaW46IHN0cmluZywgaGFzaGVkOiBzdHJpbmcpeyByZXR1cm4gY21wKHBsYWluLCBoYXNoZWQpOyB9XG5cbmV4cG9ydCBmdW5jdGlvbiBzZXRTZXNzaW9uQ29va2llKHRva2VuOiBzdHJpbmcpe1xuICBjb25zdCBqYXIgPSBjb29raWVzKCk7XG4gIGNvbnN0IHNlY3VyZSA9IFN0cmluZyhwcm9jZXNzLmVudi5DT09LSUVfU0VDVVJFfHwnZmFsc2UnKS50b0xvd2VyQ2FzZSgpID09PSAndHJ1ZSc7XG4gIGphci5zZXQoJ3Nlc3Npb24nLCB0b2tlbiwgeyBodHRwT25seTogdHJ1ZSwgc2FtZVNpdGU6ICdsYXgnLCBzZWN1cmUsIHBhdGg6ICcvJywgbWF4QWdlOiA2MCo2MCoyNCo3IH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY2xlYXJTZXNzaW9uQ29va2llKCl7XG4gIGNvbnN0IGphciA9IGNvb2tpZXMoKTtcbiAgY29uc3Qgc2VjdXJlID0gU3RyaW5nKHByb2Nlc3MuZW52LkNPT0tJRV9TRUNVUkV8fCdmYWxzZScpLnRvTG93ZXJDYXNlKCkgPT09ICd0cnVlJztcbiAgamFyLnNldCgnc2Vzc2lvbicsICcnLCB7IGh0dHBPbmx5OnRydWUsIHNhbWVTaXRlOidsYXgnLCBzZWN1cmUsIHBhdGg6Jy8nLCBtYXhBZ2U6IDAgfSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyRnJvbUNvb2tpZSgpe1xuICBjb25zdCB0b2tlbiA9IGNvb2tpZXMoKS5nZXQoJ3Nlc3Npb24nKT8udmFsdWU7XG4gIGlmICghdG9rZW4pIHJldHVybiBudWxsO1xuICB0cnl7XG4gICAgY29uc3QgZGVjOiBhbnkgPSB2ZXJpZnkodG9rZW4sIFNFQ1JFVCk7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRVbmlxdWUoeyB3aGVyZTogeyBpZDogZGVjLmlkIH0gfSk7XG4gICAgcmV0dXJuIHVzZXI7XG4gIH1jYXRjaHsgcmV0dXJuIG51bGw7IH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlcXVpcmVBZG1pbigpe1xuICBjb25zdCB1ID0gYXdhaXQgZ2V0VXNlckZyb21Db29raWUoKTtcbiAgaWYgKCF1IHx8IHUucm9sZSAhPT0gJ0FETUlOJykgdGhyb3cgT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoJ0ZvcmJpZGRlbicpLCB7IHN0YXR1czogNDAzIH0pO1xuICByZXR1cm4gdTtcbn1cbiJdLCJuYW1lcyI6WyJjb29raWVzIiwicHJpc21hIiwic2lnbiIsInZlcmlmeSIsImNvbXBhcmVQYXNzd29yZCIsImNtcCIsImhhc2hQYXNzd29yZCIsImhzaCIsIlNFQ1JFVCIsInByb2Nlc3MiLCJlbnYiLCJzaWduVG9rZW4iLCJwYXlsb2FkIiwiZXhwaXJlc0luIiwicGFzc3dvcmQiLCJwbGFpbiIsImhhc2hlZCIsInNldFNlc3Npb25Db29raWUiLCJ0b2tlbiIsImphciIsInNlY3VyZSIsIlN0cmluZyIsIkNPT0tJRV9TRUNVUkUiLCJ0b0xvd2VyQ2FzZSIsInNldCIsImh0dHBPbmx5Iiwic2FtZVNpdGUiLCJwYXRoIiwibWF4QWdlIiwiY2xlYXJTZXNzaW9uQ29va2llIiwiZ2V0VXNlckZyb21Db29raWUiLCJnZXQiLCJ2YWx1ZSIsImRlYyIsInVzZXIiLCJmaW5kVW5pcXVlIiwid2hlcmUiLCJpZCIsInJlcXVpcmVBZG1pbiIsInUiLCJyb2xlIiwiT2JqZWN0IiwiYXNzaWduIiwiRXJyb3IiLCJzdGF0dXMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./lib/auth.ts\n");

/***/ }),

/***/ "(rsc)/./lib/crypto.ts":
/*!***********************!*\
  !*** ./lib/crypto.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   comparePassword: () => (/* binding */ comparePassword),\n/* harmony export */   hashPassword: () => (/* binding */ hashPassword)\n/* harmony export */ });\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bcryptjs */ \"(rsc)/./node_modules/bcryptjs/index.js\");\n\nasync function hashPassword(password) {\n    const saltRounds = 10;\n    return bcryptjs__WEBPACK_IMPORTED_MODULE_0__.hash(password, saltRounds);\n}\nasync function comparePassword(plain, hashed) {\n    return bcryptjs__WEBPACK_IMPORTED_MODULE_0__.compare(plain, hashed);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvY3J5cHRvLnRzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFtQztBQUU1QixlQUFlQyxhQUFhQyxRQUFnQjtJQUNqRCxNQUFNQyxhQUFhO0lBQ25CLE9BQU9ILDBDQUFXLENBQUNFLFVBQVVDO0FBQy9CO0FBRU8sZUFBZUUsZ0JBQWdCQyxLQUFhLEVBQUVDLE1BQWM7SUFDakUsT0FBT1AsNkNBQWMsQ0FBQ00sT0FBT0M7QUFDL0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly85NDQtdHJhZmlrLy4vbGliL2NyeXB0by50cz85MjVhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGJjcnlwdCBmcm9tICdiY3J5cHRqcyc7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBoYXNoUGFzc3dvcmQocGFzc3dvcmQ6IHN0cmluZyl7XG4gIGNvbnN0IHNhbHRSb3VuZHMgPSAxMDtcbiAgcmV0dXJuIGJjcnlwdC5oYXNoKHBhc3N3b3JkLCBzYWx0Um91bmRzKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbXBhcmVQYXNzd29yZChwbGFpbjogc3RyaW5nLCBoYXNoZWQ6IHN0cmluZyl7XG4gIHJldHVybiBiY3J5cHQuY29tcGFyZShwbGFpbiwgaGFzaGVkKTtcbn1cbiJdLCJuYW1lcyI6WyJiY3J5cHQiLCJoYXNoUGFzc3dvcmQiLCJwYXNzd29yZCIsInNhbHRSb3VuZHMiLCJoYXNoIiwiY29tcGFyZVBhc3N3b3JkIiwicGxhaW4iLCJoYXNoZWQiLCJjb21wYXJlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./lib/crypto.ts\n");

/***/ }),

/***/ "(rsc)/./lib/db.ts":
/*!*******************!*\
  !*** ./lib/db.ts ***!
  \*******************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   prisma: () => (/* binding */ prisma)\n/* harmony export */ });\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);\n\n// Prevent multiple Prisma instances in dev (Next.js HMR)\nconst globalForPrisma = globalThis;\nconst prisma = globalForPrisma.prisma || new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient({\n    log:  true ? [\n        \"query\",\n        \"error\",\n        \"warn\"\n    ] : 0\n});\nif (true) globalForPrisma.prisma = prisma;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvZGIudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQThDO0FBRTlDLHlEQUF5RDtBQUN6RCxNQUFNQyxrQkFBa0JDO0FBRWpCLE1BQU1DLFNBQVNGLGdCQUFnQkUsTUFBTSxJQUFJLElBQUlILHdEQUFZQSxDQUFDO0lBQy9ESSxLQUFLQyxLQUF5QixHQUFnQjtRQUFDO1FBQVE7UUFBUTtLQUFPLEdBQUcsQ0FBUztBQUNwRixHQUFHO0FBRUgsSUFBSUEsSUFBeUIsRUFBY0osZ0JBQWdCRSxNQUFNLEdBQUdBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vOTQ0LXRyYWZpay8uL2xpYi9kYi50cz8xZGYwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFByaXNtYUNsaWVudCB9IGZyb20gJ0BwcmlzbWEvY2xpZW50JztcblxuLy8gUHJldmVudCBtdWx0aXBsZSBQcmlzbWEgaW5zdGFuY2VzIGluIGRldiAoTmV4dC5qcyBITVIpXG5jb25zdCBnbG9iYWxGb3JQcmlzbWEgPSBnbG9iYWxUaGlzIGFzIHVua25vd24gYXMgeyBwcmlzbWE/OiBQcmlzbWFDbGllbnQgfTtcblxuZXhwb3J0IGNvbnN0IHByaXNtYSA9IGdsb2JhbEZvclByaXNtYS5wcmlzbWEgfHwgbmV3IFByaXNtYUNsaWVudCh7XG4gIGxvZzogcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcgPyBbJ3F1ZXJ5JywnZXJyb3InLCd3YXJuJ10gOiBbJ2Vycm9yJ11cbn0pO1xuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgZ2xvYmFsRm9yUHJpc21hLnByaXNtYSA9IHByaXNtYTtcbiJdLCJuYW1lcyI6WyJQcmlzbWFDbGllbnQiLCJnbG9iYWxGb3JQcmlzbWEiLCJnbG9iYWxUaGlzIiwicHJpc21hIiwibG9nIiwicHJvY2VzcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./lib/db.ts\n");

/***/ }),

/***/ "(rsc)/./lib/email.ts":
/*!**********************!*\
  !*** ./lib/email.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   sendEmail: () => (/* binding */ sendEmail)\n/* harmony export */ });\n/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! nodemailer */ \"(rsc)/./node_modules/nodemailer/lib/nodemailer.js\");\n\nasync function trySend(opts) {\n    const { host, port, user, pass, from, to, subject, html, secure, requireTLS } = opts;\n    const transporter = nodemailer__WEBPACK_IMPORTED_MODULE_0__.createTransport({\n        host,\n        port,\n        secure,\n        auth: {\n            user,\n            pass\n        },\n        requireTLS: requireTLS ?? false,\n        logger: true // يطبع تفاصيل في السيرفر\n    }, {\n        from\n    });\n    try {\n        await transporter.verify();\n    } catch (e) {\n        console.error(\"[MAIL] verify failed\", {\n            host,\n            port,\n            secure,\n            requireTLS,\n            code: e?.code,\n            msg: e?.message\n        });\n        return {\n            ok: false,\n            error: \"VERIFY_FAIL\",\n            detail: e?.message\n        };\n    }\n    try {\n        const info = await transporter.sendMail({\n            to,\n            subject,\n            html\n        });\n        console.log(\"[MAIL] sent\", {\n            messageId: info.messageId,\n            host,\n            port\n        });\n        return {\n            ok: true\n        };\n    } catch (e) {\n        console.error(\"[MAIL] send failed\", {\n            host,\n            port,\n            code: e?.code,\n            msg: e?.message\n        });\n        return {\n            ok: false,\n            error: e?.code || \"SEND_FAIL\",\n            detail: e?.message\n        };\n    }\n}\nasync function sendEmail(to, subject, html) {\n    const host = process.env.SMTP_HOST || \"\";\n    const port = Number(process.env.SMTP_PORT || \"465\");\n    const user = process.env.SMTP_USER || \"\";\n    const pass = process.env.SMTP_PASS || \"\";\n    // اجعل FROM يطابق المستخدم إن لم يكن Alias مصرح به\n    const envFrom = process.env.SMTP_FROM || user;\n    const from = envFrom.includes(\"@\") ? envFrom : user;\n    // المحاولة الأولى: حسب الإعدادات (465→secure=true أو 587→secure=false)\n    const primary = await trySend({\n        host,\n        port,\n        user,\n        pass,\n        from,\n        to,\n        subject,\n        html,\n        secure: port === 465,\n        requireTLS: port === 587\n    });\n    if (primary.ok) return primary;\n    // إن فشل بسبب TLS/اتصال، جرّب تلقائياً 587/STARTTLS\n    if (port === 465) {\n        console.warn(\"[MAIL] primary failed on 465, retrying on 587/STARTTLS\");\n        const fallback = await trySend({\n            host,\n            port: 587,\n            user,\n            pass,\n            from,\n            to,\n            subject,\n            html,\n            secure: false,\n            requireTLS: true\n        });\n        return fallback;\n    }\n    return primary;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvZW1haWwudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBb0M7QUFJcEMsZUFBZUMsUUFBUUMsSUFBc0o7SUFDM0ssTUFBTSxFQUFFQyxJQUFJLEVBQUVDLElBQUksRUFBRUMsSUFBSSxFQUFFQyxJQUFJLEVBQUVDLElBQUksRUFBRUMsRUFBRSxFQUFFQyxPQUFPLEVBQUVDLElBQUksRUFBRUMsTUFBTSxFQUFFQyxVQUFVLEVBQUUsR0FBR1Y7SUFDaEYsTUFBTVcsY0FBY2IsdURBQTBCLENBQUM7UUFDN0NHO1FBQ0FDO1FBQ0FPO1FBQ0FJLE1BQU07WUFBRVY7WUFBTUM7UUFBSztRQUNuQk0sWUFBWUEsY0FBYztRQUMxQkksUUFBUSxLQUFnQix5QkFBeUI7SUFDbkQsR0FBRztRQUFFVDtJQUFLO0lBRVYsSUFBSTtRQUNGLE1BQU1NLFlBQVlJLE1BQU07SUFDMUIsRUFBRSxPQUFPQyxHQUFRO1FBQ2ZDLFFBQVFDLEtBQUssQ0FBQyx3QkFBd0I7WUFBRWpCO1lBQU1DO1lBQU1PO1lBQVFDO1lBQVlTLE1BQU1ILEdBQUdHO1lBQU1DLEtBQUtKLEdBQUdLO1FBQVE7UUFDdkcsT0FBTztZQUFFQyxJQUFHO1lBQU9KLE9BQU07WUFBZUssUUFBUVAsR0FBR0s7UUFBUTtJQUM3RDtJQUVBLElBQUk7UUFDRixNQUFNRyxPQUFPLE1BQU1iLFlBQVljLFFBQVEsQ0FBQztZQUFFbkI7WUFBSUM7WUFBU0M7UUFBSztRQUM1RFMsUUFBUVMsR0FBRyxDQUFDLGVBQWU7WUFBRUMsV0FBV0gsS0FBS0csU0FBUztZQUFFMUI7WUFBTUM7UUFBSztRQUNuRSxPQUFPO1lBQUVvQixJQUFHO1FBQUs7SUFDbkIsRUFBRSxPQUFPTixHQUFRO1FBQ2ZDLFFBQVFDLEtBQUssQ0FBQyxzQkFBc0I7WUFBRWpCO1lBQU1DO1lBQU1pQixNQUFNSCxHQUFHRztZQUFNQyxLQUFLSixHQUFHSztRQUFRO1FBQ2pGLE9BQU87WUFBRUMsSUFBRztZQUFPSixPQUFPRixHQUFHRyxRQUFRO1lBQWFJLFFBQVFQLEdBQUdLO1FBQVE7SUFDdkU7QUFDRjtBQUVPLGVBQWVPLFVBQVV0QixFQUFVLEVBQUVDLE9BQWUsRUFBRUMsSUFBWTtJQUN2RSxNQUFNUCxPQUFPNEIsUUFBUUMsR0FBRyxDQUFDQyxTQUFTLElBQUk7SUFDdEMsTUFBTTdCLE9BQU84QixPQUFPSCxRQUFRQyxHQUFHLENBQUNHLFNBQVMsSUFBSTtJQUM3QyxNQUFNOUIsT0FBTzBCLFFBQVFDLEdBQUcsQ0FBQ0ksU0FBUyxJQUFJO0lBQ3RDLE1BQU05QixPQUFPeUIsUUFBUUMsR0FBRyxDQUFDSyxTQUFTLElBQUk7SUFDdEMsbURBQW1EO0lBQ25ELE1BQU1DLFVBQVVQLFFBQVFDLEdBQUcsQ0FBQ08sU0FBUyxJQUFJbEM7SUFDekMsTUFBTUUsT0FBTytCLFFBQVFFLFFBQVEsQ0FBQyxPQUFPRixVQUFVakM7SUFFL0MsdUVBQXVFO0lBQ3ZFLE1BQU1vQyxVQUFzQixNQUFNeEMsUUFBUTtRQUN4Q0U7UUFBTUM7UUFBTUM7UUFBTUM7UUFBTUM7UUFBTUM7UUFBSUM7UUFBU0M7UUFDM0NDLFFBQVFQLFNBQVM7UUFDakJRLFlBQVlSLFNBQVM7SUFDdkI7SUFDQSxJQUFJcUMsUUFBUWpCLEVBQUUsRUFBRSxPQUFPaUI7SUFFdkIsb0RBQW9EO0lBQ3BELElBQUlyQyxTQUFTLEtBQUs7UUFDaEJlLFFBQVF1QixJQUFJLENBQUM7UUFDYixNQUFNQyxXQUFXLE1BQU0xQyxRQUFRO1lBQzdCRTtZQUFNQyxNQUFNO1lBQUtDO1lBQU1DO1lBQU1DO1lBQU1DO1lBQUlDO1lBQVNDO1lBQ2hEQyxRQUFRO1lBQU9DLFlBQVk7UUFDN0I7UUFDQSxPQUFPK0I7SUFDVDtJQUVBLE9BQU9GO0FBQ1QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly85NDQtdHJhZmlrLy4vbGliL2VtYWlsLnRzPzgyODEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG5vZGVtYWlsZXIgZnJvbSAnbm9kZW1haWxlcic7XG5cbnR5cGUgU2VuZFJlc3VsdCA9IHsgb2s6IHRydWUgfSB8IHsgb2s6IGZhbHNlOyBlcnJvcjogc3RyaW5nOyBkZXRhaWw/OiBzdHJpbmcgfTtcblxuYXN5bmMgZnVuY3Rpb24gdHJ5U2VuZChvcHRzOiB7IGhvc3Q6c3RyaW5nOyBwb3J0Om51bWJlcjsgdXNlcjpzdHJpbmc7IHBhc3M6c3RyaW5nOyBmcm9tOnN0cmluZzsgdG86c3RyaW5nOyBzdWJqZWN0OnN0cmluZzsgaHRtbDpzdHJpbmc7IHNlY3VyZTpib29sZWFuOyByZXF1aXJlVExTPzpib29sZWFuIH0pOiBQcm9taXNlPFNlbmRSZXN1bHQ+IHtcbiAgY29uc3QgeyBob3N0LCBwb3J0LCB1c2VyLCBwYXNzLCBmcm9tLCB0bywgc3ViamVjdCwgaHRtbCwgc2VjdXJlLCByZXF1aXJlVExTIH0gPSBvcHRzO1xuICBjb25zdCB0cmFuc3BvcnRlciA9IG5vZGVtYWlsZXIuY3JlYXRlVHJhbnNwb3J0KHtcbiAgICBob3N0LFxuICAgIHBvcnQsXG4gICAgc2VjdXJlLCAgICAgICAgICAgICAgICAgLy8gNDY1PXRydWUsIDU4Nz1mYWxzZVxuICAgIGF1dGg6IHsgdXNlciwgcGFzcyB9LFxuICAgIHJlcXVpcmVUTFM6IHJlcXVpcmVUTFMgPz8gZmFsc2UsXG4gICAgbG9nZ2VyOiB0cnVlICAgICAgICAgICAgLy8g2YrYt9io2Lkg2KrZgdin2LXZitmEINmB2Yog2KfZhNiz2YrYsdmB2LFcbiAgfSwgeyBmcm9tIH0pO1xuXG4gIHRyeSB7XG4gICAgYXdhaXQgdHJhbnNwb3J0ZXIudmVyaWZ5KCk7XG4gIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tNQUlMXSB2ZXJpZnkgZmFpbGVkJywgeyBob3N0LCBwb3J0LCBzZWN1cmUsIHJlcXVpcmVUTFMsIGNvZGU6IGU/LmNvZGUsIG1zZzogZT8ubWVzc2FnZSB9KTtcbiAgICByZXR1cm4geyBvazpmYWxzZSwgZXJyb3I6J1ZFUklGWV9GQUlMJywgZGV0YWlsOiBlPy5tZXNzYWdlIH07XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGluZm8gPSBhd2FpdCB0cmFuc3BvcnRlci5zZW5kTWFpbCh7IHRvLCBzdWJqZWN0LCBodG1sIH0pO1xuICAgIGNvbnNvbGUubG9nKCdbTUFJTF0gc2VudCcsIHsgbWVzc2FnZUlkOiBpbmZvLm1lc3NhZ2VJZCwgaG9zdCwgcG9ydCB9KTtcbiAgICByZXR1cm4geyBvazp0cnVlIH07XG4gIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tNQUlMXSBzZW5kIGZhaWxlZCcsIHsgaG9zdCwgcG9ydCwgY29kZTogZT8uY29kZSwgbXNnOiBlPy5tZXNzYWdlIH0pO1xuICAgIHJldHVybiB7IG9rOmZhbHNlLCBlcnJvcjogZT8uY29kZSB8fCAnU0VORF9GQUlMJywgZGV0YWlsOiBlPy5tZXNzYWdlIH07XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRFbWFpbCh0bzogc3RyaW5nLCBzdWJqZWN0OiBzdHJpbmcsIGh0bWw6IHN0cmluZyk6IFByb21pc2U8U2VuZFJlc3VsdD4ge1xuICBjb25zdCBob3N0ID0gcHJvY2Vzcy5lbnYuU01UUF9IT1NUIHx8ICcnO1xuICBjb25zdCBwb3J0ID0gTnVtYmVyKHByb2Nlc3MuZW52LlNNVFBfUE9SVCB8fCAnNDY1Jyk7XG4gIGNvbnN0IHVzZXIgPSBwcm9jZXNzLmVudi5TTVRQX1VTRVIgfHwgJyc7XG4gIGNvbnN0IHBhc3MgPSBwcm9jZXNzLmVudi5TTVRQX1BBU1MgfHwgJyc7XG4gIC8vINin2KzYudmEIEZST00g2YrYt9in2KjZgiDYp9mE2YXYs9iq2K7Yr9mFINil2YYg2YTZhSDZitmD2YYgQWxpYXMg2YXYtdix2K0g2KjZh1xuICBjb25zdCBlbnZGcm9tID0gcHJvY2Vzcy5lbnYuU01UUF9GUk9NIHx8IHVzZXI7XG4gIGNvbnN0IGZyb20gPSBlbnZGcm9tLmluY2x1ZGVzKCdAJykgPyBlbnZGcm9tIDogdXNlcjtcblxuICAvLyDYp9mE2YXYrdin2YjZhNipINin2YTYo9mI2YTZiTog2K3Ys9ioINin2YTYpdi52K/Yp9iv2KfYqiAoNDY14oaSc2VjdXJlPXRydWUg2KPZiCA1ODfihpJzZWN1cmU9ZmFsc2UpXG4gIGNvbnN0IHByaW1hcnk6IFNlbmRSZXN1bHQgPSBhd2FpdCB0cnlTZW5kKHtcbiAgICBob3N0LCBwb3J0LCB1c2VyLCBwYXNzLCBmcm9tLCB0bywgc3ViamVjdCwgaHRtbCxcbiAgICBzZWN1cmU6IHBvcnQgPT09IDQ2NSxcbiAgICByZXF1aXJlVExTOiBwb3J0ID09PSA1ODdcbiAgfSk7XG4gIGlmIChwcmltYXJ5Lm9rKSByZXR1cm4gcHJpbWFyeTtcblxuICAvLyDYpdmGINmB2LTZhCDYqNiz2KjYqCBUTFMv2KfYqti12KfZhNiMINis2LHZkdioINiq2YTZgtin2KbZitin2YsgNTg3L1NUQVJUVExTXG4gIGlmIChwb3J0ID09PSA0NjUpIHtcbiAgICBjb25zb2xlLndhcm4oJ1tNQUlMXSBwcmltYXJ5IGZhaWxlZCBvbiA0NjUsIHJldHJ5aW5nIG9uIDU4Ny9TVEFSVFRMUycpO1xuICAgIGNvbnN0IGZhbGxiYWNrID0gYXdhaXQgdHJ5U2VuZCh7XG4gICAgICBob3N0LCBwb3J0OiA1ODcsIHVzZXIsIHBhc3MsIGZyb20sIHRvLCBzdWJqZWN0LCBodG1sLFxuICAgICAgc2VjdXJlOiBmYWxzZSwgcmVxdWlyZVRMUzogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBmYWxsYmFjaztcbiAgfVxuXG4gIHJldHVybiBwcmltYXJ5O1xufVxuIl0sIm5hbWVzIjpbIm5vZGVtYWlsZXIiLCJ0cnlTZW5kIiwib3B0cyIsImhvc3QiLCJwb3J0IiwidXNlciIsInBhc3MiLCJmcm9tIiwidG8iLCJzdWJqZWN0IiwiaHRtbCIsInNlY3VyZSIsInJlcXVpcmVUTFMiLCJ0cmFuc3BvcnRlciIsImNyZWF0ZVRyYW5zcG9ydCIsImF1dGgiLCJsb2dnZXIiLCJ2ZXJpZnkiLCJlIiwiY29uc29sZSIsImVycm9yIiwiY29kZSIsIm1zZyIsIm1lc3NhZ2UiLCJvayIsImRldGFpbCIsImluZm8iLCJzZW5kTWFpbCIsImxvZyIsIm1lc3NhZ2VJZCIsInNlbmRFbWFpbCIsInByb2Nlc3MiLCJlbnYiLCJTTVRQX0hPU1QiLCJOdW1iZXIiLCJTTVRQX1BPUlQiLCJTTVRQX1VTRVIiLCJTTVRQX1BBU1MiLCJlbnZGcm9tIiwiU01UUF9GUk9NIiwiaW5jbHVkZXMiLCJwcmltYXJ5Iiwid2FybiIsImZhbGxiYWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./lib/email.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/semver","vendor-chunks/jsonwebtoken","vendor-chunks/lodash.includes","vendor-chunks/jws","vendor-chunks/lodash.once","vendor-chunks/jwa","vendor-chunks/lodash.isinteger","vendor-chunks/ecdsa-sig-formatter","vendor-chunks/lodash.isplainobject","vendor-chunks/ms","vendor-chunks/lodash.isstring","vendor-chunks/lodash.isnumber","vendor-chunks/lodash.isboolean","vendor-chunks/safe-buffer","vendor-chunks/buffer-equal-constant-time","vendor-chunks/bcryptjs","vendor-chunks/zod","vendor-chunks/nodemailer"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute&page=%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fbookings%2Fupdate%2Froute.ts&appDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();