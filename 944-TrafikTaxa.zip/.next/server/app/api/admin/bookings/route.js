"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/admin/bookings/route";
exports.ids = ["app/api/admin/bookings/route"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "../../client/components/action-async-storage.external":
/*!*******************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external.js" ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/action-async-storage.external.js");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!********************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external.js" ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/request-async-storage.external.js");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!******************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external.js" ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/static-generation-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fadmin%2Fbookings%2Froute&page=%2Fapi%2Fadmin%2Fbookings%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fbookings%2Froute.ts&appDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fadmin%2Fbookings%2Froute&page=%2Fapi%2Fadmin%2Fbookings%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fbookings%2Froute.ts&appDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_moses_Projects_Websites_944_TrafikTaxa_app_api_admin_bookings_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/admin/bookings/route.ts */ \"(rsc)/./app/api/admin/bookings/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/admin/bookings/route\",\n        pathname: \"/api/admin/bookings\",\n        filename: \"route\",\n        bundlePath: \"app/api/admin/bookings/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\moses\\\\Projects\\\\Websites\\\\944-TrafikTaxa\\\\app\\\\api\\\\admin\\\\bookings\\\\route.ts\",\n    nextConfigOutput,\n    userland: C_Users_moses_Projects_Websites_944_TrafikTaxa_app_api_admin_bookings_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/admin/bookings/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZhZG1pbiUyRmJvb2tpbmdzJTJGcm91dGUmcGFnZT0lMkZhcGklMkZhZG1pbiUyRmJvb2tpbmdzJTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGYWRtaW4lMkZib29raW5ncyUyRnJvdXRlLnRzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNtb3NlcyU1Q1Byb2plY3RzJTVDV2Vic2l0ZXMlNUM5NDQtVHJhZmlrVGF4YSU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9QyUzQSU1Q1VzZXJzJTVDbW9zZXMlNUNQcm9qZWN0cyU1Q1dlYnNpdGVzJTVDOTQ0LVRyYWZpa1RheGEmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFzRztBQUN2QztBQUNjO0FBQ3lDO0FBQ3RIO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnSEFBbUI7QUFDM0M7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsaUVBQWlFO0FBQ3pFO0FBQ0E7QUFDQSxXQUFXLDRFQUFXO0FBQ3RCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDdUg7O0FBRXZIIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vOTQ0LXRyYWZpay8/NGM2MiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBSb3V0ZVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvYXBwLXJvdXRlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJDOlxcXFxVc2Vyc1xcXFxtb3Nlc1xcXFxQcm9qZWN0c1xcXFxXZWJzaXRlc1xcXFw5NDQtVHJhZmlrVGF4YVxcXFxhcHBcXFxcYXBpXFxcXGFkbWluXFxcXGJvb2tpbmdzXFxcXHJvdXRlLnRzXCI7XG4vLyBXZSBpbmplY3QgdGhlIG5leHRDb25maWdPdXRwdXQgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IG5leHRDb25maWdPdXRwdXQgPSBcIlwiXG5jb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBSb3V0ZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUk9VVEUsXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9hZG1pbi9ib29raW5ncy9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2FkbWluL2Jvb2tpbmdzXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS9hZG1pbi9ib29raW5ncy9yb3V0ZVwiXG4gICAgfSxcbiAgICByZXNvbHZlZFBhZ2VQYXRoOiBcIkM6XFxcXFVzZXJzXFxcXG1vc2VzXFxcXFByb2plY3RzXFxcXFdlYnNpdGVzXFxcXDk0NC1UcmFmaWtUYXhhXFxcXGFwcFxcXFxhcGlcXFxcYWRtaW5cXFxcYm9va2luZ3NcXFxccm91dGUudHNcIixcbiAgICBuZXh0Q29uZmlnT3V0cHV0LFxuICAgIHVzZXJsYW5kXG59KTtcbi8vIFB1bGwgb3V0IHRoZSBleHBvcnRzIHRoYXQgd2UgbmVlZCB0byBleHBvc2UgZnJvbSB0aGUgbW9kdWxlLiBUaGlzIHNob3VsZFxuLy8gYmUgZWxpbWluYXRlZCB3aGVuIHdlJ3ZlIG1vdmVkIHRoZSBvdGhlciByb3V0ZXMgdG8gdGhlIG5ldyBmb3JtYXQuIFRoZXNlXG4vLyBhcmUgdXNlZCB0byBob29rIGludG8gdGhlIHJvdXRlLlxuY29uc3QgeyByZXF1ZXN0QXN5bmNTdG9yYWdlLCBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcyB9ID0gcm91dGVNb2R1bGU7XG5jb25zdCBvcmlnaW5hbFBhdGhuYW1lID0gXCIvYXBpL2FkbWluL2Jvb2tpbmdzL3JvdXRlXCI7XG5mdW5jdGlvbiBwYXRjaEZldGNoKCkge1xuICAgIHJldHVybiBfcGF0Y2hGZXRjaCh7XG4gICAgICAgIHNlcnZlckhvb2tzLFxuICAgICAgICBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlXG4gICAgfSk7XG59XG5leHBvcnQgeyByb3V0ZU1vZHVsZSwgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIG9yaWdpbmFsUGF0aG5hbWUsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fadmin%2Fbookings%2Froute&page=%2Fapi%2Fadmin%2Fbookings%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fbookings%2Froute.ts&appDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/admin/bookings/route.ts":
/*!*****************************************!*\
  !*** ./app/api/admin/bookings/route.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/db */ \"(rsc)/./lib/db.ts\");\n/* harmony import */ var _lib_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/lib/auth */ \"(rsc)/./lib/auth.ts\");\n\n\n\nasync function GET() {\n    try {\n        await (0,_lib_auth__WEBPACK_IMPORTED_MODULE_2__.requireAdmin)();\n    } catch (e) {\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            ok: false,\n            error: \"Forbidden\"\n        }, {\n            status: e?.status || 403\n        });\n    }\n    const rides = await _lib_db__WEBPACK_IMPORTED_MODULE_1__.prisma.ride.findMany({\n        orderBy: {\n            createdAt: \"desc\"\n        },\n        include: {\n            user: true\n        }\n    });\n    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n        ok: true,\n        rides\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2FkbWluL2Jvb2tpbmdzL3JvdXRlLnRzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBMkM7QUFDVDtBQUNRO0FBRW5DLGVBQWVHO0lBQ3BCLElBQUc7UUFDRCxNQUFNRCx1REFBWUE7SUFDcEIsRUFBQyxPQUFNRSxHQUFNO1FBQ1gsT0FBT0oscURBQVlBLENBQUNLLElBQUksQ0FBQztZQUFFQyxJQUFHO1lBQU9DLE9BQU07UUFBWSxHQUFHO1lBQUVDLFFBQVFKLEdBQUdJLFVBQVE7UUFBSTtJQUNyRjtJQUNBLE1BQU1DLFFBQVEsTUFBTVIsMkNBQU1BLENBQUNTLElBQUksQ0FBQ0MsUUFBUSxDQUFDO1FBQUVDLFNBQVE7WUFBRUMsV0FBVTtRQUFPO1FBQUdDLFNBQVE7WUFBRUMsTUFBSztRQUFLO0lBQUU7SUFDL0YsT0FBT2YscURBQVlBLENBQUNLLElBQUksQ0FBQztRQUFFQyxJQUFHO1FBQU1HO0lBQU07QUFDNUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly85NDQtdHJhZmlrLy4vYXBwL2FwaS9hZG1pbi9ib29raW5ncy9yb3V0ZS50cz9lMjAzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5leHRSZXNwb25zZSB9IGZyb20gJ25leHQvc2VydmVyJztcbmltcG9ydCB7IHByaXNtYSB9IGZyb20gJ0AvbGliL2RiJztcbmltcG9ydCB7IHJlcXVpcmVBZG1pbiB9IGZyb20gJ0AvbGliL2F1dGgnO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gR0VUKCl7XG4gIHRyeXtcbiAgICBhd2FpdCByZXF1aXJlQWRtaW4oKTtcbiAgfWNhdGNoKGU6YW55KXtcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBvazpmYWxzZSwgZXJyb3I6J0ZvcmJpZGRlbicgfSwgeyBzdGF0dXM6IGU/LnN0YXR1c3x8NDAzIH0pO1xuICB9XG4gIGNvbnN0IHJpZGVzID0gYXdhaXQgcHJpc21hLnJpZGUuZmluZE1hbnkoeyBvcmRlckJ5OnsgY3JlYXRlZEF0OidkZXNjJyB9LCBpbmNsdWRlOnsgdXNlcjp0cnVlIH0gfSk7XG4gIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IG9rOnRydWUsIHJpZGVzIH0pO1xufVxuIl0sIm5hbWVzIjpbIk5leHRSZXNwb25zZSIsInByaXNtYSIsInJlcXVpcmVBZG1pbiIsIkdFVCIsImUiLCJqc29uIiwib2siLCJlcnJvciIsInN0YXR1cyIsInJpZGVzIiwicmlkZSIsImZpbmRNYW55Iiwib3JkZXJCeSIsImNyZWF0ZWRBdCIsImluY2x1ZGUiLCJ1c2VyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/admin/bookings/route.ts\n");

/***/ }),

/***/ "(rsc)/./lib/auth.ts":
/*!*********************!*\
  !*** ./lib/auth.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   clearSessionCookie: () => (/* binding */ clearSessionCookie),\n/* harmony export */   comparePassword: () => (/* binding */ comparePassword),\n/* harmony export */   getUserFromCookie: () => (/* binding */ getUserFromCookie),\n/* harmony export */   hashPassword: () => (/* binding */ hashPassword),\n/* harmony export */   requireAdmin: () => (/* binding */ requireAdmin),\n/* harmony export */   setSessionCookie: () => (/* binding */ setSessionCookie),\n/* harmony export */   signToken: () => (/* binding */ signToken)\n/* harmony export */ });\n/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/headers */ \"(rsc)/./node_modules/next/dist/api/headers.js\");\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/db */ \"(rsc)/./lib/db.ts\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jsonwebtoken */ \"(rsc)/./node_modules/jsonwebtoken/index.js\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _lib_crypto__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/lib/crypto */ \"(rsc)/./lib/crypto.ts\");\n\n\n\n\nconst SECRET = process.env.SECRET || \"change_me_dev_secret\";\nfunction signToken(payload) {\n    return (0,jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__.sign)(payload, SECRET, {\n        expiresIn: \"7d\"\n    });\n}\nasync function hashPassword(password) {\n    return (0,_lib_crypto__WEBPACK_IMPORTED_MODULE_3__.hashPassword)(password);\n}\nasync function comparePassword(plain, hashed) {\n    return (0,_lib_crypto__WEBPACK_IMPORTED_MODULE_3__.comparePassword)(plain, hashed);\n}\nfunction setSessionCookie(token) {\n    const jar = (0,next_headers__WEBPACK_IMPORTED_MODULE_0__.cookies)();\n    const secure = String(process.env.COOKIE_SECURE || \"false\").toLowerCase() === \"true\";\n    jar.set(\"session\", token, {\n        httpOnly: true,\n        sameSite: \"lax\",\n        secure,\n        path: \"/\",\n        maxAge: 60 * 60 * 24 * 7\n    });\n}\nfunction clearSessionCookie() {\n    const jar = (0,next_headers__WEBPACK_IMPORTED_MODULE_0__.cookies)();\n    const secure = String(process.env.COOKIE_SECURE || \"false\").toLowerCase() === \"true\";\n    jar.set(\"session\", \"\", {\n        httpOnly: true,\n        sameSite: \"lax\",\n        secure,\n        path: \"/\",\n        maxAge: 0\n    });\n}\nasync function getUserFromCookie() {\n    const token = (0,next_headers__WEBPACK_IMPORTED_MODULE_0__.cookies)().get(\"session\")?.value;\n    if (!token) return null;\n    try {\n        const dec = (0,jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__.verify)(token, SECRET);\n        const user = await _lib_db__WEBPACK_IMPORTED_MODULE_1__.prisma.user.findUnique({\n            where: {\n                id: dec.id\n            }\n        });\n        return user;\n    } catch  {\n        return null;\n    }\n}\nasync function requireAdmin() {\n    const u = await getUserFromCookie();\n    if (!u || u.role !== \"ADMIN\") throw Object.assign(new Error(\"Forbidden\"), {\n        status: 403\n    });\n    return u;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvYXV0aC50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBdUM7QUFDTDtBQUNVO0FBQytCO0FBRTNFLE1BQU1RLFNBQVNDLFFBQVFDLEdBQUcsQ0FBQ0YsTUFBTSxJQUFJO0FBRTlCLFNBQVNHLFVBQVVDLE9BQTRCO0lBQ3BELE9BQU9WLGtEQUFJQSxDQUFDVSxTQUFTSixRQUFRO1FBQUVLLFdBQVc7SUFBSztBQUNqRDtBQUVPLGVBQWVQLGFBQWFRLFFBQWdCO0lBQUcsT0FBT1AseURBQUdBLENBQUNPO0FBQVc7QUFDckUsZUFBZVYsZ0JBQWdCVyxLQUFhLEVBQUVDLE1BQWM7SUFBRyxPQUFPWCw0REFBR0EsQ0FBQ1UsT0FBT0M7QUFBUztBQUUxRixTQUFTQyxpQkFBaUJDLEtBQWE7SUFDNUMsTUFBTUMsTUFBTW5CLHFEQUFPQTtJQUNuQixNQUFNb0IsU0FBU0MsT0FBT1osUUFBUUMsR0FBRyxDQUFDWSxhQUFhLElBQUUsU0FBU0MsV0FBVyxPQUFPO0lBQzVFSixJQUFJSyxHQUFHLENBQUMsV0FBV04sT0FBTztRQUFFTyxVQUFVO1FBQU1DLFVBQVU7UUFBT047UUFBUU8sTUFBTTtRQUFLQyxRQUFRLEtBQUcsS0FBRyxLQUFHO0lBQUU7QUFDckc7QUFFTyxTQUFTQztJQUNkLE1BQU1WLE1BQU1uQixxREFBT0E7SUFDbkIsTUFBTW9CLFNBQVNDLE9BQU9aLFFBQVFDLEdBQUcsQ0FBQ1ksYUFBYSxJQUFFLFNBQVNDLFdBQVcsT0FBTztJQUM1RUosSUFBSUssR0FBRyxDQUFDLFdBQVcsSUFBSTtRQUFFQyxVQUFTO1FBQU1DLFVBQVM7UUFBT047UUFBUU8sTUFBSztRQUFLQyxRQUFRO0lBQUU7QUFDdEY7QUFFTyxlQUFlRTtJQUNwQixNQUFNWixRQUFRbEIscURBQU9BLEdBQUcrQixHQUFHLENBQUMsWUFBWUM7SUFDeEMsSUFBSSxDQUFDZCxPQUFPLE9BQU87SUFDbkIsSUFBRztRQUNELE1BQU1lLE1BQVc5QixvREFBTUEsQ0FBQ2UsT0FBT1Y7UUFDL0IsTUFBTTBCLE9BQU8sTUFBTWpDLDJDQUFNQSxDQUFDaUMsSUFBSSxDQUFDQyxVQUFVLENBQUM7WUFBRUMsT0FBTztnQkFBRUMsSUFBSUosSUFBSUksRUFBRTtZQUFDO1FBQUU7UUFDbEUsT0FBT0g7SUFDVCxFQUFDLE9BQUs7UUFBRSxPQUFPO0lBQU07QUFDdkI7QUFFTyxlQUFlSTtJQUNwQixNQUFNQyxJQUFJLE1BQU1UO0lBQ2hCLElBQUksQ0FBQ1MsS0FBS0EsRUFBRUMsSUFBSSxLQUFLLFNBQVMsTUFBTUMsT0FBT0MsTUFBTSxDQUFDLElBQUlDLE1BQU0sY0FBYztRQUFFQyxRQUFRO0lBQUk7SUFDeEYsT0FBT0w7QUFDVCIsInNvdXJjZXMiOlsid2VicGFjazovLzk0NC10cmFmaWsvLi9saWIvYXV0aC50cz9iZjdlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNvb2tpZXMgfSBmcm9tICduZXh0L2hlYWRlcnMnO1xuaW1wb3J0IHsgcHJpc21hIH0gZnJvbSAnQC9saWIvZGInO1xuaW1wb3J0IHsgc2lnbiwgdmVyaWZ5IH0gZnJvbSAnanNvbndlYnRva2VuJztcbmltcG9ydCB7IGNvbXBhcmVQYXNzd29yZCBhcyBjbXAsIGhhc2hQYXNzd29yZCBhcyBoc2ggfSBmcm9tICdAL2xpYi9jcnlwdG8nO1xuXG5jb25zdCBTRUNSRVQgPSBwcm9jZXNzLmVudi5TRUNSRVQgfHwgJ2NoYW5nZV9tZV9kZXZfc2VjcmV0JztcblxuZXhwb3J0IGZ1bmN0aW9uIHNpZ25Ub2tlbihwYXlsb2FkOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KXtcbiAgcmV0dXJuIHNpZ24ocGF5bG9hZCwgU0VDUkVULCB7IGV4cGlyZXNJbjogJzdkJyB9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhc2hQYXNzd29yZChwYXNzd29yZDogc3RyaW5nKXsgcmV0dXJuIGhzaChwYXNzd29yZCk7IH1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjb21wYXJlUGFzc3dvcmQocGxhaW46IHN0cmluZywgaGFzaGVkOiBzdHJpbmcpeyByZXR1cm4gY21wKHBsYWluLCBoYXNoZWQpOyB9XG5cbmV4cG9ydCBmdW5jdGlvbiBzZXRTZXNzaW9uQ29va2llKHRva2VuOiBzdHJpbmcpe1xuICBjb25zdCBqYXIgPSBjb29raWVzKCk7XG4gIGNvbnN0IHNlY3VyZSA9IFN0cmluZyhwcm9jZXNzLmVudi5DT09LSUVfU0VDVVJFfHwnZmFsc2UnKS50b0xvd2VyQ2FzZSgpID09PSAndHJ1ZSc7XG4gIGphci5zZXQoJ3Nlc3Npb24nLCB0b2tlbiwgeyBodHRwT25seTogdHJ1ZSwgc2FtZVNpdGU6ICdsYXgnLCBzZWN1cmUsIHBhdGg6ICcvJywgbWF4QWdlOiA2MCo2MCoyNCo3IH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY2xlYXJTZXNzaW9uQ29va2llKCl7XG4gIGNvbnN0IGphciA9IGNvb2tpZXMoKTtcbiAgY29uc3Qgc2VjdXJlID0gU3RyaW5nKHByb2Nlc3MuZW52LkNPT0tJRV9TRUNVUkV8fCdmYWxzZScpLnRvTG93ZXJDYXNlKCkgPT09ICd0cnVlJztcbiAgamFyLnNldCgnc2Vzc2lvbicsICcnLCB7IGh0dHBPbmx5OnRydWUsIHNhbWVTaXRlOidsYXgnLCBzZWN1cmUsIHBhdGg6Jy8nLCBtYXhBZ2U6IDAgfSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyRnJvbUNvb2tpZSgpe1xuICBjb25zdCB0b2tlbiA9IGNvb2tpZXMoKS5nZXQoJ3Nlc3Npb24nKT8udmFsdWU7XG4gIGlmICghdG9rZW4pIHJldHVybiBudWxsO1xuICB0cnl7XG4gICAgY29uc3QgZGVjOiBhbnkgPSB2ZXJpZnkodG9rZW4sIFNFQ1JFVCk7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRVbmlxdWUoeyB3aGVyZTogeyBpZDogZGVjLmlkIH0gfSk7XG4gICAgcmV0dXJuIHVzZXI7XG4gIH1jYXRjaHsgcmV0dXJuIG51bGw7IH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlcXVpcmVBZG1pbigpe1xuICBjb25zdCB1ID0gYXdhaXQgZ2V0VXNlckZyb21Db29raWUoKTtcbiAgaWYgKCF1IHx8IHUucm9sZSAhPT0gJ0FETUlOJykgdGhyb3cgT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoJ0ZvcmJpZGRlbicpLCB7IHN0YXR1czogNDAzIH0pO1xuICByZXR1cm4gdTtcbn1cbiJdLCJuYW1lcyI6WyJjb29raWVzIiwicHJpc21hIiwic2lnbiIsInZlcmlmeSIsImNvbXBhcmVQYXNzd29yZCIsImNtcCIsImhhc2hQYXNzd29yZCIsImhzaCIsIlNFQ1JFVCIsInByb2Nlc3MiLCJlbnYiLCJzaWduVG9rZW4iLCJwYXlsb2FkIiwiZXhwaXJlc0luIiwicGFzc3dvcmQiLCJwbGFpbiIsImhhc2hlZCIsInNldFNlc3Npb25Db29raWUiLCJ0b2tlbiIsImphciIsInNlY3VyZSIsIlN0cmluZyIsIkNPT0tJRV9TRUNVUkUiLCJ0b0xvd2VyQ2FzZSIsInNldCIsImh0dHBPbmx5Iiwic2FtZVNpdGUiLCJwYXRoIiwibWF4QWdlIiwiY2xlYXJTZXNzaW9uQ29va2llIiwiZ2V0VXNlckZyb21Db29raWUiLCJnZXQiLCJ2YWx1ZSIsImRlYyIsInVzZXIiLCJmaW5kVW5pcXVlIiwid2hlcmUiLCJpZCIsInJlcXVpcmVBZG1pbiIsInUiLCJyb2xlIiwiT2JqZWN0IiwiYXNzaWduIiwiRXJyb3IiLCJzdGF0dXMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./lib/auth.ts\n");

/***/ }),

/***/ "(rsc)/./lib/crypto.ts":
/*!***********************!*\
  !*** ./lib/crypto.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   comparePassword: () => (/* binding */ comparePassword),\n/* harmony export */   hashPassword: () => (/* binding */ hashPassword)\n/* harmony export */ });\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bcryptjs */ \"(rsc)/./node_modules/bcryptjs/index.js\");\n\nasync function hashPassword(password) {\n    const saltRounds = 10;\n    return bcryptjs__WEBPACK_IMPORTED_MODULE_0__.hash(password, saltRounds);\n}\nasync function comparePassword(plain, hashed) {\n    return bcryptjs__WEBPACK_IMPORTED_MODULE_0__.compare(plain, hashed);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvY3J5cHRvLnRzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFtQztBQUU1QixlQUFlQyxhQUFhQyxRQUFnQjtJQUNqRCxNQUFNQyxhQUFhO0lBQ25CLE9BQU9ILDBDQUFXLENBQUNFLFVBQVVDO0FBQy9CO0FBRU8sZUFBZUUsZ0JBQWdCQyxLQUFhLEVBQUVDLE1BQWM7SUFDakUsT0FBT1AsNkNBQWMsQ0FBQ00sT0FBT0M7QUFDL0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly85NDQtdHJhZmlrLy4vbGliL2NyeXB0by50cz85MjVhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGJjcnlwdCBmcm9tICdiY3J5cHRqcyc7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBoYXNoUGFzc3dvcmQocGFzc3dvcmQ6IHN0cmluZyl7XG4gIGNvbnN0IHNhbHRSb3VuZHMgPSAxMDtcbiAgcmV0dXJuIGJjcnlwdC5oYXNoKHBhc3N3b3JkLCBzYWx0Um91bmRzKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbXBhcmVQYXNzd29yZChwbGFpbjogc3RyaW5nLCBoYXNoZWQ6IHN0cmluZyl7XG4gIHJldHVybiBiY3J5cHQuY29tcGFyZShwbGFpbiwgaGFzaGVkKTtcbn1cbiJdLCJuYW1lcyI6WyJiY3J5cHQiLCJoYXNoUGFzc3dvcmQiLCJwYXNzd29yZCIsInNhbHRSb3VuZHMiLCJoYXNoIiwiY29tcGFyZVBhc3N3b3JkIiwicGxhaW4iLCJoYXNoZWQiLCJjb21wYXJlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./lib/crypto.ts\n");

/***/ }),

/***/ "(rsc)/./lib/db.ts":
/*!*******************!*\
  !*** ./lib/db.ts ***!
  \*******************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   prisma: () => (/* binding */ prisma)\n/* harmony export */ });\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);\n\n// Prevent multiple Prisma instances in dev (Next.js HMR)\nconst globalForPrisma = globalThis;\nconst prisma = globalForPrisma.prisma || new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient({\n    log:  true ? [\n        \"query\",\n        \"error\",\n        \"warn\"\n    ] : 0\n});\nif (true) globalForPrisma.prisma = prisma;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvZGIudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQThDO0FBRTlDLHlEQUF5RDtBQUN6RCxNQUFNQyxrQkFBa0JDO0FBRWpCLE1BQU1DLFNBQVNGLGdCQUFnQkUsTUFBTSxJQUFJLElBQUlILHdEQUFZQSxDQUFDO0lBQy9ESSxLQUFLQyxLQUF5QixHQUFnQjtRQUFDO1FBQVE7UUFBUTtLQUFPLEdBQUcsQ0FBUztBQUNwRixHQUFHO0FBRUgsSUFBSUEsSUFBeUIsRUFBY0osZ0JBQWdCRSxNQUFNLEdBQUdBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vOTQ0LXRyYWZpay8uL2xpYi9kYi50cz8xZGYwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFByaXNtYUNsaWVudCB9IGZyb20gJ0BwcmlzbWEvY2xpZW50JztcblxuLy8gUHJldmVudCBtdWx0aXBsZSBQcmlzbWEgaW5zdGFuY2VzIGluIGRldiAoTmV4dC5qcyBITVIpXG5jb25zdCBnbG9iYWxGb3JQcmlzbWEgPSBnbG9iYWxUaGlzIGFzIHVua25vd24gYXMgeyBwcmlzbWE/OiBQcmlzbWFDbGllbnQgfTtcblxuZXhwb3J0IGNvbnN0IHByaXNtYSA9IGdsb2JhbEZvclByaXNtYS5wcmlzbWEgfHwgbmV3IFByaXNtYUNsaWVudCh7XG4gIGxvZzogcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcgPyBbJ3F1ZXJ5JywnZXJyb3InLCd3YXJuJ10gOiBbJ2Vycm9yJ11cbn0pO1xuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgZ2xvYmFsRm9yUHJpc21hLnByaXNtYSA9IHByaXNtYTtcbiJdLCJuYW1lcyI6WyJQcmlzbWFDbGllbnQiLCJnbG9iYWxGb3JQcmlzbWEiLCJnbG9iYWxUaGlzIiwicHJpc21hIiwibG9nIiwicHJvY2VzcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./lib/db.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/semver","vendor-chunks/jsonwebtoken","vendor-chunks/lodash.includes","vendor-chunks/jws","vendor-chunks/lodash.once","vendor-chunks/jwa","vendor-chunks/lodash.isinteger","vendor-chunks/ecdsa-sig-formatter","vendor-chunks/lodash.isplainobject","vendor-chunks/ms","vendor-chunks/lodash.isstring","vendor-chunks/lodash.isnumber","vendor-chunks/lodash.isboolean","vendor-chunks/safe-buffer","vendor-chunks/buffer-equal-constant-time","vendor-chunks/bcryptjs"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fadmin%2Fbookings%2Froute&page=%2Fapi%2Fadmin%2Fbookings%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fadmin%2Fbookings%2Froute.ts&appDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cmoses%5CProjects%5CWebsites%5C944-TrafikTaxa&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();