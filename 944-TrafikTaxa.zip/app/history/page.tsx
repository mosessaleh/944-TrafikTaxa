"use client";
export default function HistoryRedirect(){ if(typeof window!=='undefined'){ window.location.href='/account?tab=history'; } return null; }
