import AccountClient from "@/components/account-client";
export default function AccountPage() {
  return <AccountClient />;
}
